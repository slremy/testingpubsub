/*
I just copied frank.cpp to bellow.cpp for consistency and put  #define frank true
  if it was frank and if not then #define frank false
By the way, you can try this with a server of any (size of allocatable memory) size and
it will run invert and revert and what not with the server.
setup():
  This makes contact with the server, or tries, when given an ip address and port number
  It then returns the socket
string heyServer_InvertThis(string message, int sock):
  Give a message, with some header info with server and client agreed upon SIZE_INDEX
  SIZE_INDEX specifies the format as 7 bytes for number of messages, followed by 7 bytes
    that declare the size of the following message including the header info.
  You then get back that same message, only inverted... with that same header.
catcher(int notUsed):
  Handles printing and catches if ctrl-c is pressed.
string messageNumToString(int n, int length):
  returns the header for the message. It is in ascii so you can read it
  while you are using tcpdump. This greatly reduces the number of bytes 
  you can send. But, I think 9,999,999 bytes is quite enough. 
string toSend(string s, int total):
  concatenates the header with the message in one function
string received(string s):
  removes the header from the message
process_flags():
  Does the same as the last.
  takes in the flags and parses the input
main():
  does the actual connecting after setup
  sends and receives, then send and receive. 
 */
#include <iostream>
#include <cstdlib>
#include <string>
#include <cstring>
#include <algorithm>
#include <vector>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include "Practical.h"
#include <fstream>
#define isFrank false
using namespace std;
struct SharedData {
  double start;
  int attempts;
  int where;
  string echoString;
  string inverted;
  string reverted;
};
SharedData glbl;
int setup(const char *host, const char  *service);
string heyServer_InvertThis(string message, int sock);
#define  SIZE_INDEX 7
void catcher(int notUsed) {
  cout << "\r    \r" << glbl.attempts << "\t";
  printf("%.6lf\t", (double)(clock() - glbl.start)/CLOCKS_PER_SEC);
  cout << glbl.echoString << "\t";
  if (glbl.where > 0) {
    cout << glbl.inverted << "\t";
  }
  if (glbl.where > 1) {
    cout << (glbl.echoString == glbl.reverted  ? "Verified" : "Invalid");
  }
  cout << endl;
  exit(0);
}
/* ~~~~~~~~~~~~~~~~~~~~~~~ My Encoding ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
string messageNumToString(int n, int length) {
  string s = to_string(n);
  while (s.length() < SIZE_INDEX)
    s = "0" + s;
  int realLength = length + SIZE_INDEX * 2;
  string s2 = to_string(realLength);
  while (s2.length() < SIZE_INDEX)
    s2 = "0"  + s2;
  return s + s2;
}
string toSend(string s, int total) {
  return messageNumToString(total, s.length()) + s;
}
string received(string s) {
  if (SIZE_INDEX * 2  > s.length())
    return "";
  return s.substr(SIZE_INDEX * 2, s.length());
}

/* ~~~~~~~~~~~~~~~~~~~~~~~ Process Flags ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
string processFlags(int argc, char *argv[], char **server, char **servPort);
int main(int argc, char *argv[]) {
  struct sigaction sigIntHandler;
  sigIntHandler.sa_handler = catcher;
  sigemptyset(&sigIntHandler.sa_mask);
  sigIntHandler.sa_flags = 0;
  sigaction(SIGINT, &sigIntHandler, NULL);
  //getting flags
  char *server, *servPort;
  glbl.echoString = processFlags(argc, argv, &server, &servPort);
  if (server == NULL || glbl.echoString.length() == 0 || servPort == NULL) {
    cout << "Wrong Parameters" << endl;
    cout << "-s <Server Address/Name> -m <Echo Message> -p [<Server Port/Service>]" << endl;
    exit(-1);
  }
  int sock = setup(server, servPort);

  if (isFrank) {
    string message = toSend(glbl.echoString, 2);
    glbl.inverted = received(heyServer_InvertThis(message, sock));
    glbl.where++;
    message = toSend(glbl.inverted, 2);
    glbl.reverted = received(heyServer_InvertThis(message, sock));
    glbl.where++;
  } else {
    string message = toSend(glbl.echoString, 1);
    glbl.inverted = received(heyServer_InvertThis(message, sock));
    glbl.where++;
  }
  close(sock);
  catcher(0);
  return 0;
}
string heyServer_InvertThis(string message, int sock) {
  glbl.attempts++;
  //sending the null character for termination of stream;
  char *buffer = new char[message.length()];
  int length = message.length();
  for (int i = 0; i < length; i++) buffer[i] = message[i];
  int total = 0, bytes = 0;
  while (total < length) {
    bytes = send(sock, buffer + total, length - total, 0);
    if (bytes < 0) {
      cout << "Our send failed :(" << endl;
      exit(-1);
    }
    total += bytes;
  }
  total = 0;
  while (total < length) {
    bytes = recv(sock, buffer + total, length - total, 0);
    if (bytes < 0) {
      cout << "Receive went horribly wrong, we are now crashing and burning..." << endl;
      exit(-1);
    } else if (bytes == 0) {
      cout << "We are not done receiving.. This is unfair..." << endl;
      exit(-1);
    }
    total += bytes;
  }
  string s = "";
  for (int i = 0; i < length; i++)
    s += buffer[i];
  delete[] buffer;

  return s;
}
int setup(const char *host, const char  *service) {
    // Tell the system what kind(s) of address info we want
  struct addrinfo addrCriteria;                   // Criteria for address match
  memset(&addrCriteria, 0, sizeof(addrCriteria)); // Zero out structure
  addrCriteria.ai_family = AF_UNSPEC;             // v4 or v6 is OK
  addrCriteria.ai_socktype = SOCK_STREAM;         // Only streaming sockets
  addrCriteria.ai_protocol = IPPROTO_TCP;         // Only TCP protocol


  // get address
  struct addrinfo *servAddr;
  int rtnVal = getaddrinfo(host, service, &addrCriteria, &servAddr);
  if (rtnVal != 0) {
    cout << "getaddrinfo() failed in setup" << endl;
    exit(-1);
  }
  int sock = -1;
  for (struct addrinfo *addr = servAddr; addr != NULL; addr = addr->ai_next) {
    // Crearte a reliable, stream socket using TCP
    sock = socket(addr->ai_family, addr->ai_socktype, addr->ai_protocol);
    if (sock < 0) continue; // it failed, try next
    //establish the connection
    if (connect(sock, addr->ai_addr, addr->ai_addrlen) == 0)
      break; // we did it!
    
    close(sock); // we did not...
    sock = -1;
  }
  freeaddrinfo(servAddr);
  return sock;
}




string processFlags(int argc, char *argv[], char **server, char **servPort) {
  int i;
  string echoString;
  *server = NULL; *servPort = NULL;
  for (i = 1; i < argc - 1; i++) {
    if (argv[i][0] == '-') {
      if (argv[i][1] == 's') {
	*server = argv[++i];
      }
      if (argv[i][1] == 'p') {
	*servPort = argv[++i];
      }
      if (argv[i][1] == 'm') {
	echoString = string(argv[++i]);
	//handles random cases
	while (++i < argc && (argv[i][0] != '-' || argv[i][1] == 0 || argv[i][2] != 0)) {
	  echoString = echoString + " " + string(argv[i]);
	}
	echoString += "\0";
	i--;
      }
      if (argv[i][1] == 'f') {
	string filename = string(argv[++i]);
	string buffer = "";
	ifstream fin(filename);
	char c;
	while (fin >> c) echoString += c;

	fin.close();
      }
    }
  }
  return string(echoString);
}
