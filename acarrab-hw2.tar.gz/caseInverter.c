/*
  ------------------------------------------------------------------------------
  This file consists of, 

  Results structure:
    -contains 
      * number of messages 
      * string versions of IPs for print out
      * number of unique IPs

  void catcher():
    - Catches the program before it ends with ctrl-c
    - Prints out the required output.

  void addClient(AddressStruct address):
    - Increments the number of messages sent
    - Takes in the address from the structure, struct sockaddr_storage, 
        through function in AddressUtility.c
    - Stores the printable version of the IP address in results if it
        is unique

  char * processFlags(int argc, char *argv[]):
    - Processes the single -p (port) attribute
    - Returns NULL if it fails.

  int main(argc, char  *argv[]):
    - Initializes 
      * struct sigaction for catching ctrl-c
      * Results structure that is defined globally
    - Recieves message through UDP
    - Inverts the case of the received message
    - Sends the message back


 */
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include "Practical.h"

typedef struct sockaddr_storage AddressStruct;
typedef struct RESULTS {
  int messages;
  char **IPs;
  int size;
  int count;
} Results;

Results results;
//Prints at ctrl-c
void catcher() {
  printf("\r  \r%d\t", results.messages);
  if (results.count > 0)
    printf("%s", results.IPs[0]);
  int i = 1;

  for (; i < results.count; i++) {
    printf(", %s", results.IPs[i]);
    free(results.IPs[i]);
  }
  free(results.IPs);
  printf("\n");

  exit(0);
}
//lazy way of doing this to get rid of identical
void addClient (AddressStruct address) {
  results.messages++;

  //dynamic allocation of values
  if (results.size <= results.count) {
    results.size *= 2;
    char **temp = results.IPs;
    results.IPs = (char **)malloc(sizeof(char *) * results.size);
    memcpy(results.IPs, temp, sizeof(char *) * results.size / 2);
    free(temp);
  }

  int i = 0;
  char *IP;
  SocketAddressToString((struct sockaddr *)&address, &IP);
  if (IP == NULL) return;
  
  //go through and check 1 by 1 (O(n))
  for (; i < results.count; i++)
    if (strcmp(results.IPs[i], IP) == 0) return;

  results.IPs[results.count++] = IP;
}

char * processFlags(int argc, char *argv[]) {
  int i;
  char *servPort = NULL;

  for (i = 1; i < argc - 1; i++)
    if (strcmp(argv[i], "-p") == 0) 
      servPort = argv[++i];
    
  return servPort;
}
void FuncFail(const char *func) {
  fprintf(stderr, "%s failed\n", func);
  exit(-1);
}
int main(int argc, char *argv[]) {
  //catches after ctrl-c command
  struct sigaction sigIntHandler;
  sigIntHandler.sa_handler = catcher;
  sigemptyset(&sigIntHandler.sa_mask);
  sigIntHandler.sa_flags = 0;
  sigaction(SIGINT, &sigIntHandler, NULL);
    
  results.size = 2;
  results.count = 0;
  results.messages = 0;
  results.IPs = (char **)malloc(sizeof(char) * 2);

  char *service = processFlags(argc, argv);
  if (service == NULL) 
    FuncFail("invalid arguments -p <Server Port/Service> \nInit");

  // Construct the server address structure
  struct addrinfo addrCriteria;                   // Criteria for address
  memset(&addrCriteria, 0, sizeof(addrCriteria)); // Zero out structure
  addrCriteria.ai_family = AF_UNSPEC;             // Any address family
  addrCriteria.ai_flags = AI_PASSIVE;             // Accept on any address/port
  addrCriteria.ai_socktype = SOCK_DGRAM;          // Only datagram socket
  addrCriteria.ai_protocol = IPPROTO_UDP;         // Only UDP socket

  struct addrinfo *servAddr; // List of server addresses
  int rtnVal = getaddrinfo(NULL, service, &addrCriteria, &servAddr);
  if (rtnVal != 0)
    FuncFail("getaddrinfo()");

  // Create socket for incoming connections
  int sock = socket(servAddr->ai_family, servAddr->ai_socktype,
      servAddr->ai_protocol);

  if (sock < 0)
    FuncFail("socket()");

  // Bind to the local address
  if (bind(sock, servAddr->ai_addr, servAddr->ai_addrlen) < 0)
    FuncFail("bind()");

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  for (;;) { // Run forever
    struct sockaddr_storage clntAddr; // Client address
    // Set Length of client address structure (in-out parameter)
    socklen_t clntAddrLen = sizeof(clntAddr);

    // Block until receive message from a client
    char buffer[MAXSTRINGLENGTH]; // I/O buffer
    // Size of received message
    ssize_t numBytesRcvd = recvfrom(sock, buffer, MAXSTRINGLENGTH, 0,
        (struct sockaddr *) &clntAddr, &clntAddrLen);

    if (numBytesRcvd < 0)
      FuncFail("recvfrom()");

    //addClient function, described at top
    addClient(clntAddr);

    //Inverts alphabet characters
    int c; 
    for (c = 0; c < numBytesRcvd; c++) {
       if ('a' <= buffer[c] && buffer[c]  <= 'z')
	 buffer[c] += 'A' - 'a';
       else if ('A' <= buffer[c] && buffer[c] <= 'Z') 
	 buffer[c] = buffer[c] - 'A' + 'a';
    }

    // Send received datagram back to the client
    ssize_t numBytesSent = sendto(sock, buffer, numBytesRcvd, 0,
        (struct sockaddr *) &clntAddr, sizeof(clntAddr));
    if (numBytesSent < 0)
      FuncFail("sendto()");
    else if (numBytesSent != numBytesRcvd)
      FuncFail("sent unexpected number of bytes: sendto()");
  }
}
