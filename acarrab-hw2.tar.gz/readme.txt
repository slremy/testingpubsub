In order to set up, 

1. run makefile with "make"
2. run server with a proper server port in 5K to 10K range
3. run the yeller or checker with the server port, IP address, and message

Note: bellower/frank  and caseConvert must be ran in different terminals as
server has to be only active process.

------------------ Command Line Arguments --------------------------------------
./caseConverter -p <server port (between 5k and 10k)>
./bellower -p <servers port> -m <message> -s <IP address>
./frank -p <servers port> -m <message> -s <IP address>

./caseInverter -p <server port (between 5k and 10k)>
./yeller -p <servers port> -m <message> -s <IP address>
./checker -p <servers port> -m <message> -s <IP address>

=============================  Example  =======================================


~~~~~~~~~~~~~~~~~~~~~~~~~~  TERMINAL 1 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
[18:03:15] acarrab@koala10:~/Desktop/cpsc3600/hw1 [1] make
g++ caseConverter.cpp AddressUtility.cpp -std=c++11 -o caseConverter
g++ bellower.cpp -std=c++11 -o bellower
g++ frank.cpp -std=c++11 -o frank
gcc yeller.c AddressUtility.c ClientTools.c -o yeller
gcc checker.c AddressUtility.c ClientTools.c -o checker
gcc caseInverter.c AddressUtility.c Practical.h -o caseInverter
[18:03:17] acarrab@koala10:~/Desktop/cpsc3600/hw1 [2] ./caseInverter -p 5500


start TCP dump in a third terminal with similar tags. I was running locally so I used -i lo. I was also listening on port 5500 because that was the port my server was on.
~~~~~~~~~~~~~~~~~~~~~~~~~~  TERMINAL 3 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
[18:03:15] acarrab@koala10:~/Desktop/cpsc3600/hw1 [1] sudo tcpdump -i lo -A
port 5500 -w "tcpdata.pcap"
[18:03:17] acarrab@koala10:~/Desktop/cpsc3600/hw1 [2]


bellower and frank accept either string in parenthesis or without on the
argument line and spaces it out automatically by one space.
~~~~~~~~~~~~~~~~~~~~~~~~~~  TERMINAL 2 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
[18:04:41] user@compy:~/Dir [1] ./bellower -p 5500 -m "Hello World" -s 127.0.0.1
1       0.000237	Hello World	hELLO wORLD	
[18:05:07] user@compy:~/Dir [2] ./frank -p 5500 -m "Hello World" -s 127.0.0.1
2       0.000359	Hello World	hELLO wORLD	Verified



Going back to terminal 1 and ctrl-c to stop server
~~~~~~~~~~~~~~~~~~~~~~~~~~  TERMINAL 1 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
[18:03:17] acarrab@koala10:~/Desktop/cpsc3600/hw1 [2] ./caseConverter -p 5500
11       127.0.0.1
[18:08:52] acarrab@koala10:~/Desktop/cpsc3600/hw1 [3] 
