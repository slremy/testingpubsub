/*
  void Main ():
   - handles just connecting to server with functions from ClientTools.h
   - resends the response and checks if it is the same of the original.
  void catcher():
   - prints out results stored in global(glbl) data
   SharedData:
   - keeps track of relevant printing data;
*/
#include <time.h>
#include "ClientTools.h"

typedef struct SHAREDATA {
  double start;
  int attempts;
  int where;
  char *echoString;
  char *inverted;
  char *reverted;
} SharedData;

//global data that has to be shared with the catcher
SharedData glbl;

void catcher() {
  printf("\r    \r%d\t"    , glbl.attempts);
  printf("%.6lf\t" , (double)(clock() - glbl.start)/CLOCKS_PER_SEC);
  printf("%s\t", glbl.echoString);
  if (glbl.where > 0) {
    printf("%s\t", glbl.inverted);
    free(glbl.inverted);
  }
  if (glbl.where > 1) {
    printf("%s", strcmp(glbl.echoString, glbl.reverted) == 0 ?  
	   "Verified" : "Invalid");
    free(glbl.reverted);
  }
  printf("\n");
  exit(0);
}
int main(int argc, char *argv[]) {
  struct sigaction sigIntHandler;
  sigIntHandler.sa_handler = catcher;
  sigemptyset(&sigIntHandler.sa_mask);
  sigIntHandler.sa_flags = 0;
  sigaction(SIGINT, &sigIntHandler, NULL);
  //getting flags
  char *server, *servPort;
  glbl.echoString = processFlags(argc, argv, &server, &servPort);
  if (server == NULL || glbl.echoString == NULL || servPort == NULL) {
    fprintf(stderr, "Parameter(s): ");
    fprintf(stderr, "-s <Server Address/Name> ");
    fprintf(stderr, "-m <Echo Message> ");
    fprintf(stderr, "-p [<Server Port/Service>]\n");
    exit(-1);
  }
  
  //cant be longer than the message buffer
  if (strlen(glbl.echoString) > MAXSTRINGLENGTH) {
    fprintf(stderr, "%s is too long\n", glbl.echoString);
    exit(-1);
  }
  
  //starting timer
  glbl.start = clock();



  shared_info info;
  glbl.inverted = (char *)malloc(sizeof(char)*(MAXSTRINGLENGTH + 1));
  for(glbl.attempts = 1; glbl.attempts < 20; glbl.attempts++) {
    if (0 != sendOverUDP(server, servPort, glbl.echoString, &info)) continue;
    if (0 != recieveOverUDP(glbl.inverted, glbl.echoString, &info)) continue;
    break;
  }

  glbl.where++;
  glbl.reverted = (char *)malloc(sizeof(char)*(MAXSTRINGLENGTH + 1));
  int tries = glbl.attempts + 20;
  glbl.attempts++;
  for(; glbl.attempts < tries; glbl.attempts++) {
    if (0 != sendOverUDP(server, servPort, glbl.inverted, &info)) continue;
    if (0 != recieveOverUDP(glbl.reverted, glbl.inverted, &info)) continue;
    break;
  }
  glbl.where++;
  catcher();

  return 0;
}
