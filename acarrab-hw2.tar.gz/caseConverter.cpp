/*
int setup(const char *service):
  sets up server on the given port.
int accept(int servSock):
  waits for someone to connect with us and then does.
int messagesToReceive(string received):
  gets the total number of expected messages that will be send during connection
  *it is checked every message
getMessageLength():
  Gets the total message length that we are expecting.
void invert(char *s, int n):
  Case Inverts a string s of length n
int handle(int clntSocket):
  Handles the receiving and sending of information between the client and the server
char *processFlags():
  simply gets the servers port with -p tag
void catcher():
  does the final printing when ctrl-c is pressed
void addClient():
  Adds a client to a list if it is a new one
  increments the message counter


 */
#include <iostream>
#include <string>
#include <cstring>
#include <cstdlib>
#include <vector>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h>
#include "Practical.h"
#include <signal.h>
using namespace std;

static const int MAXPENDING = 5; // Maximum outstanding connection requests.
#define SIZE_INDEX  7 //size of messages allowed and place

int setup(const char *service);
int accept(int servSock);
int messagesToReceive(char header[SIZE_INDEX * 2]);
int getMessageLength(char header[SIZE_INDEX * 2]);
void invert(char *toConvert, int length);
int handle(int clntSocket);
char * processFlags(int argc, char *argv[]);
void catcher(int notUsed);
void addClient(struct sockaddr_storage address);


struct Results {
  int messages;
  vector<string> IPs;
  int servSock;
};
Results results;

int main(int argc, char *argv[]) {
  //catches after ctrl-c command
  struct sigaction sigIntHandler;
  sigIntHandler.sa_handler = catcher;
  sigemptyset(&sigIntHandler.sa_mask);
  sigIntHandler.sa_flags = 0;
  sigaction(SIGINT, &sigIntHandler, NULL);

  char *service = processFlags(argc, argv);
  if (service == NULL)  {
    cout << "invalid arguments -p <Server Port/Service>" << endl;
    return -1;
  }
  int servSock = setup(service);
  if (servSock < 0) {
    cout << "setup failed" << endl;
    return -1;
  }
  results.servSock = servSock;
  for(;;) {
    int clntSock = accept(servSock);
    if (0 != handle(clntSock)) {
      cout << "error in handling" << endl;
      return -1;
    }
    close(clntSock);
  }
  return 0;
}


int setup(const char *service) {
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_UNSPEC;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  struct addrinfo *servAddr;
  int rtnVal = getaddrinfo(NULL, service, &addrCriteria, &servAddr);
  if (rtnVal != 0) {
    cout << "getaddrinfo failed" << endl;
    return -1;
  }
  int servSock = -1;
  for (struct addrinfo *addr = servAddr; addr != NULL; addr = addr->ai_next) {
    // Creating TCP socket
    servSock = socket(addr->ai_family, addr->ai_socktype, addr->ai_protocol);
    // We are making sockets until we find one is open apparently
    if (servSock < 0) continue;
    if ((bind(servSock, addr->ai_addr, addr->ai_addrlen) == 0) &&
        (listen(servSock, MAXPENDING) == 0)) {
      // Print local address of socket
      struct sockaddr_storage localAddr;
      socklen_t addrSize = sizeof(localAddr);
      if (getsockname(servSock, (struct sockaddr *) &localAddr, &addrSize) < 0) {
        cout << "getsockname() failed" << endl;
	return -1;
      }
      break;       // Bind and listen successful
    }
    close(servSock);  // Close and try again
    servSock = -1;
  }

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);
  return servSock;
}
int accept(int servSock) {
  struct sockaddr_storage clntAddr;
  socklen_t clntAddrLen = sizeof(clntAddr);
  //wait for client
  int clntSock = accept(servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
  addClient(clntAddr);
  if (clntSock < 0) {
    cout << "Accept Failed" << endl;
    return -1;
  }
  return clntSock;
}
int messagesToReceive(char header[SIZE_INDEX * 2]) {
  //first 7 characters define number of messages known to be sent at least
  int mssgs = 0;
  for (int i = 0; i < SIZE_INDEX; i++) {
    mssgs *= 10;
    mssgs += int(header[i] - '0');
  }
  return mssgs;
}
int getMessageLength(char header[SIZE_INDEX * 2]) {
  //second 7 characters contain this information
  int msgLen = 0;
  for (int i = 0; i < SIZE_INDEX; i++) {
    msgLen *= 10;
    msgLen += int(header[SIZE_INDEX + i] - '0');
  }
  return msgLen;
}
void invert(char *toConvert, int length) {
  for (int i = 0; i < length; i++) {
    if (isupper(toConvert[i]))
      toConvert[i] = tolower(toConvert[i]);
    else if (islower(toConvert[i]))
      toConvert[i] = toupper(toConvert[i]);
  }
}

int handle(int clntSocket) {
  int totalRcvd = 0, maxKnown = 1;

  while (totalRcvd < maxKnown) {
    int headerLength = 2 * SIZE_INDEX;
    char header[SIZE_INDEX * 2];
    int total = 0, bytes = 0;
    while (total < headerLength) {
      bytes = recv(clntSocket, header + total, headerLength - total, 0);
      if (bytes < 0) {
	cout << "server recv() failed " << endl;
	exit(-1);
      }
      results.messages++;
      total += bytes;
    }
    int messageLength = getMessageLength(header);
    maxKnown = max(maxKnown, messagesToReceive(header));
    char *buffer = new char[messageLength];
    //copying header to large buffer
    for (int i = 0; i < headerLength; i++) buffer[i] = header[i];

    while(total < messageLength) {
      bytes = recv(clntSocket, buffer + total, messageLength - total, 0);
      if (bytes < 0) {
	cout << "problem with second recv() statement" << endl;
	exit(-1);
      }
      results.messages++;
      total+= bytes;
    }
    invert(buffer, messageLength);
    int toSend = total;
    total = 0;
    while(total < toSend) {
      bytes = send(clntSocket, buffer + total, toSend - total, 0);
      total += bytes;
      results.messages++;
    }
    totalRcvd++;
    delete[] buffer;
  }
  close(clntSocket);
  return 0;
}

char * processFlags(int argc, char *argv[]) {
  int i;
  char *servPort = NULL;

  for (i = 1; i < argc - 1; i++)
    if (strcmp(argv[i], "-p") == 0) 
      servPort = argv[++i];
    
  return servPort;
}

void catcher(int notUsed)  {
  cout << "\r   \r" << results.messages << "\t";
  for (int i = 0; i < results.IPs.size(); i++) 
    cout << results.IPs[i] << ", ";
  cout << endl;
  close(results.servSock);
  exit(0);
}

void addClient(struct sockaddr_storage address) {
  results.messages++;
  char *IP;
  SocketAddressToString((struct sockaddr *)&address, &IP);
  if (IP == NULL) return;
  string s = string(IP);
  bool isThere = false;
  for (int i = 0; i < results.IPs.size(); i++)
    if (results.IPs[i] == s)
      isThere = true;
  if (!isThere)
    results.IPs.push_back(s);
}
