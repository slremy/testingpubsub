/*
  look in ClientTools.h for reference
 */
#include "ClientTools.h"

char * processFlags(int argc, char *argv[], char **server, char **servPort) {
  int i;
  char *echoString = NULL;
  *server = NULL; *servPort = NULL;
  for (i = 1; i < argc - 1; i++) {
    if (argv[i][0] == '-') {
      if (argv[i][1] == 's') {
	*server = argv[++i];
      }
      if (argv[i][1] == 'p') {
	*servPort = argv[++i];
      }
      if (argv[i][1] == 'm') {
	echoString = (char *)malloc(sizeof(char)*128);
	strcpy(echoString, argv[++i]);
	//handles random cases
	while (++i < argc && (argv[i][0] != '-' || argv[i][1] == 0 || argv[i][2] != 0)) {
	  strcat(echoString, " ");
	  strcat(echoString, argv[i]);
	}
	strcat(echoString, "\0");
	i--;
      }
    }
  }
  return echoString;
}

void FuncFail(const char *func) {
  fprintf(stderr, "%s failed\n", func);
  exit(-1);
}

int sendOverUDP(char *server, char *servPort, char *echoString, shared_info *info) {
//struct addrinfo *servAddr, ssize_t *numBytes, int *sock) {
  // Tell the system what kind(s) of address info we want
  struct addrinfo addrCriteria;                   // Criteria for address match
  memset(&addrCriteria, 0, sizeof(addrCriteria)); // Zero out structure
  addrCriteria.ai_family = AF_UNSPEC;             // Any address family
  // For the following fields, a zero value means "don't care"
  addrCriteria.ai_socktype = SOCK_DGRAM;          // Only datagram sockets
  addrCriteria.ai_protocol = IPPROTO_UDP;         // Only UDP protocol

  // Get address(es)
  int rtnVal = getaddrinfo(server, servPort, &addrCriteria, &(info->servAddr));
  if (rtnVal != 0)
    FuncFail("getaddrinfo()");


  
  // Create a datagram/UDP socket
  info->sock = socket(info->servAddr->ai_family, info->servAddr->ai_socktype,
      info->servAddr->ai_protocol); // Socket descriptor for client

  if (info->sock < 0)
    FuncFail("socket()");
  
  // Send the string to the server
  ssize_t numBytes = sendto(info->sock, echoString, strlen(echoString), 0,
      info->servAddr->ai_addr, info->servAddr->ai_addrlen);
  if (numBytes < 0)
    FuncFail("sendto()");


  else if (numBytes != strlen(echoString))
    FuncFail("Too many bytes: sendto()");


  return 0;
}

int recieveOverUDP(char *buffer, char *echoString, shared_info *info) {
  // Receive a response
  struct sockaddr_storage fromAddr; // Source address of server
  // Set length of from address structure (in-out parameter)
  socklen_t fromAddrLen = sizeof(fromAddr);
  ssize_t numBytes = recvfrom(info->sock, buffer, MAXSTRINGLENGTH, 0,
      (struct sockaddr *) &fromAddr, &fromAddrLen);
  if (numBytes < 0)
    FuncFail("recvfrom()");
  else if (numBytes != strlen(echoString))
    FuncFail("Unexpected number of bytes: recvfrom()");
  buffer[numBytes] = '\0';

  // Verify reception from expected source
  if (!SockAddrsEqual(info->servAddr->ai_addr, (struct sockaddr *) &fromAddr))
    FuncFail("recieved a packet from an unknown source: recvfrom()");

  freeaddrinfo(info->servAddr);

  close(info->sock);
  return 0;
}
