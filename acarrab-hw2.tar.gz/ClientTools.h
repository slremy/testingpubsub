/*
  keeps track of most of the shared data for client1 and client2
  
  char * processFlags():
    - Handles collecting of all flags
    - if you type -m foo -bar, the outcoming string will be
       "foo -bar" excluding quotation marks, as long as bar is 
       not a valid tag
  int sendOverUDP():
    - If this returns 0 it went well, otherwise there was a problem.
    - This will often quit within if it does fail, because some failures
        wont be fixed if ran again.
  int recieveOverUDP():
    - If this returns 0 it went well, otherwise there was a problem.
    - this will often quit within if it does fail, because some failures
        wont be fixed if ran again.
    - must pass in an allocated buffer.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netdb.h>
#include "Practical.h"

typedef struct SHARED_INFO {
  struct addrinfo *servAddr;
  int sock;
} shared_info;

//global data that has to be shared with the catcher



char * processFlags(int argc, char *argv[], char **server, char **servPort);
int sendOverUDP(char *server, char *servPort, char *echoString, shared_info *info);
int recieveOverUDP(char *buffer, char *echoString, shared_info *info);
