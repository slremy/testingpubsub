In order to set up, 

1. run makefile with "make"
2. run server with a proper server port in 5K to 10K range
3. run the yeller or checker with the server port, IP address, and message

Note: server.c and client.c must be ran in different terminals as server
has to be only active process.

------------------ Command Line Arguments --------------------------------------
./caseInverter -p <server port (between 5k and 10k)>
./yeller -p <servers port> -m <message> -s <IP address>
./checker -p <servers port> -m <message> -s <IP address>

=============================  Example  =======================================


~~~~~~~~~~~~~~~~~~~~~~~~~~  TERMINAL 1 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
[18:03:15] acarrab@koala10:~/Desktop/cpsc3600/hw1 [1] make
gcc Client1.c AddressUtility.c ClientTools.c -o yeller
gcc Client2.c AddressUtility.c ClientTools.c -o checker
gcc Server.c AddressUtility.c Practical.h -o caseInverter
[18:03:17] acarrab@koala10:~/Desktop/cpsc3600/hw1 [2] ./caseInverter -p 5500




yeller and sender accept either string in parenthesis or without on the argument
line and spaces it out automatically by one space.
~~~~~~~~~~~~~~~~~~~~~~~~~~  TERMINAL 2 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
[18:04:41] user@compy:~/Dir [1] ./yeller -p 5500 -m "Hello World" -s 127.0.0.1
1       0.000237	Hello World	hELLO wORLD	
[18:04:59] user@compy:~/Dir [2] ./yeller -p 5500 -m Hello World -s 127.0.0.1
1       0.000233	Hello World	hELLO wORLD	
[18:05:07] user@compy:~/Dir [3] ./checker -p 5500 -m "Hello World" -s 127.0.0.1
2       0.000359	Hello World	hELLO wORLD	Verified
[18:05:22] user@compy:~/Dir [4] ./checker -p 5500 -m Hello World -s 127.0.0.1
2       0.000348	Hello World	hELLO wORLD	Verified


Going back to terminal 1 and ctrl-c to stop server
~~~~~~~~~~~~~~~~~~~~~~~~~~  TERMINAL 1 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
[18:03:17] acarrab@koala10:~/Desktop/cpsc3600/hw1 [2] ./caseInverter -p 5500
8       127.0.0.1
[18:08:52] acarrab@koala10:~/Desktop/cpsc3600/hw1 [3] 
